import React, { Component } from "react";
import { QUESTIONS } from "./questions";

class App extends Component {
  state = {
    answers: [],
    averageScore: null,
  };

  handleAnswer = (answer, index) => {
    const newAnswers = [...this.state.answers];
    newAnswers[index] = answer;
    this.setState({ answers: newAnswers });
  };

  calculateScore = (answers) => {
    const yesCount = answers.filter((answer) => answer === "Yes").length;
    return (yesCount / answers.length) * 100;
  };

  handleSubmit = () => {
    const { answers } = this.state;
    const score = this.calculateScore(answers);
    this.setState({ averageScore: score.toFixed(2) });
  };

  resetQuiz = () => {
    this.setState({ answers: [], averageScore: null });
  };

  render() {
    const { answers, averageScore } = this.state;
    const allQuestionsAnswered = Object.keys(QUESTIONS).every(
      (index) => answers[index]
    );

    return (
      <div className="main__wrap">
        <main className="container">
          <h1>Quiz Questions</h1>
          {Object.keys(QUESTIONS).map((index) => (
            <div key={index}>
              <h2>Question {index}</h2>
              <p>{QUESTIONS[index]}</p>
              <div>
                <button onClick={() => this.handleAnswer("Yes", index)}>
                  Yes
                </button>
                <button onClick={() => this.handleAnswer("No", index)}>
                  No
                </button>
              </div>
            </div>
          ))}
          {allQuestionsAnswered && (
            <div>
              <button onClick={this.handleSubmit}>Submit Answers</button>
            </div>
          )}
          {averageScore !== null && (
            <div>
              <h1>Quiz completed!</h1>
              <p>Your score for this run: {averageScore}%</p>
              <button onClick={this.resetQuiz}>Restart Quiz</button>
            </div>
          )}
          {averageScore !== null && (
            <div>
              <h1>Overall Score</h1>
              <p>Average score for all runs: {averageScore}%</p>
            </div>
          )}
        </main>
      </div>
    );
  }
}

export default App;
