import React, { Component } from "react";
import { QUESTIONS } from "./questions";

class App extends Component {
  state = {
    currentQuestionIndex: 1,
    answers: [],
    averageScore: 0,
  };

  handleAnswer = (answer) => {
    const { answers, currentQuestionIndex } = this.state;
    const newAnswers = [...answers, answer];
    this.setState(
      {
        answers: newAnswers,
        currentQuestionIndex: currentQuestionIndex + 1,
      },
      () => {
        const score = this.calculateScore(newAnswers);
        console.log(`Your score for this run: ${score}%`);
        this.calculateAverageScore();
      }
    );
  };

  calculateScore = (answers) => {
    const yesCount = answers.filter((answer) => answer === "Yes").length;
    const score = (yesCount / answers.length) * 100;
    return score.toFixed(2);
  };

  calculateAverageScore = () => {
    const { answers } = this.state;
    const totalScore = answers.reduce((acc, answer) => {
      if (answer === "Yes") {
        return acc + 1;
      } else {
        return acc;
      }
    }, 0);
    const avgScore = (totalScore / answers.length) * 100 || 0;
    this.setState({ averageScore: avgScore.toFixed(2) });
  };

  resetQuiz = () => {
    this.setState({ answers: [], currentQuestionIndex: 1, averageScore: 0 });
  };

  render() {
    const { currentQuestionIndex, averageScore } = this.state;
    return (
      <div className="main__wrap">
        <main className="container">
          {currentQuestionIndex <= Object.keys(QUESTIONS).length ? (
            <div>
              <h1>Question {currentQuestionIndex}</h1>
              <p>{QUESTIONS[currentQuestionIndex]}</p>
              <div>
                <button onClick={() => this.handleAnswer("Yes")}>Yes</button>
                <button onClick={() => this.handleAnswer("No")}>No</button>
              </div>
            </div>
          ) : (
            <div>
              <h1>Quiz completed!</h1>
              <p>
                Your score for this run:{" "}
                {this.calculateScore(this.state.answers)}%
              </p>
              <p>Average score for all runs: {averageScore}%</p>
              <button onClick={this.resetQuiz}>Restart Quiz</button>
            </div>
          )}
        </main>
      </div>
    );
  }
}

export default App;
